package middlewares

import (
	"context"
	"fmt"
	"github.com/golang-jwt/jwt/v5"
	"net/http"
	"os"
	"socialnet/pkg/utils"
	"strings"
)

var paths = []string{
	"/api/v1/auth/login",
	"/api/v1/auth/register",
	"/api/v1/auth/refresh",
	"/api/v1/auth/update-password",
	"/api/v1/auth/forgot-password",
	"/api/v1/auth/reset-password",
}

func AuthMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		// 🔓 Пропускаем публичные маршруты
		for _, path := range paths {
			if strings.HasPrefix(r.URL.Path, path) {
				next.ServeHTTP(w, r)
				return
			}
		}

		// 🔑 Достаём заголовок
		authHeader := r.Header.Get("Authorization")
		if authHeader == "" {
			http.Error(w, "Missing Authorization header", http.StatusUnauthorized)
			return
		}

		// Ожидаем формат: "Bearer <token>"
		parts := strings.Split(authHeader, " ")
		if len(parts) != 2 || strings.ToLower(parts[0]) != "bearer" {
			http.Error(w, "Invalid Authorization header format", http.StatusUnauthorized)
			return
		}
		tokenString := parts[1]

		// 🔐 Валидируем токен
		jwtSecret := os.Getenv("JWT_SECRET")
		parsedToken, err := jwt.Parse(tokenString, func(token *jwt.Token) (interface{}, error) {
			if _, ok := token.Method.(*jwt.SigningMethodHMAC); !ok {
				return nil, fmt.Errorf("Unexpected signing method: %v", token.Header["alg"])
			}
			return []byte(jwtSecret), nil
		})
		if err != nil {
			http.Error(w, "Invalid token: "+err.Error(), http.StatusUnauthorized)
			return
		}

		claims, ok := parsedToken.Claims.(jwt.MapClaims)
		if !ok || !parsedToken.Valid {
			http.Error(w, "Invalid token claims", http.StatusUnauthorized)
			return
		}

		// 📌 Кладём в context
		ctx := r.Context()

		userId, _ := claims["sub"].(string)
		username, _ := claims["name"].(string)
		exp, _ := claims["exp"].(float64)

		if userId != "" {
			ctx = context.WithValue(ctx, utils.UserIDKey, userId)
		}
		if username != "" {
			ctx = context.WithValue(ctx, utils.UsernameKey, username)
		}
		if exp > 0 {
			ctx = context.WithValue(ctx, utils.ExpKey, int64(exp))
		}

		next.ServeHTTP(w, r.WithContext(ctx))
	})
}
